---------------------------------------------------------------------------
-- FlightDash Widget
-- EdgeTX 2.11+
---------------------------------------------------------------------------

local name = "flightDash"

---------------------------------------------------------------------------
-- OPTIONS (9 total)
---------------------------------------------------------------------------

local options = {
  { "Arm",       SOURCE, 0 },
  { "Motor",     SOURCE, 0 },
  { "Rx Batt",   SOURCE, 0 },
  { "Rx Signal", SOURCE, 0 },
  { "Rx Qty",    SOURCE, 0 },
  { "Esc Tmp",   SOURCE, 0 },
  { "Rpm",       SOURCE, 0 },
  { "Curr",      SOURCE, 0 },
  { "GV",        SOURCE, 0 },
  { "Rx Cells",  SOURCE, 0 }
}

---------------------------------------------------------------------------
-- CREATE / UPDATE
---------------------------------------------------------------------------

local function create(zone, opts)
  return {
    zone = zone,
    options = opts or {}
  }
end

local function update(widget, opts)
  widget.options = opts
end

---------------------------------------------------------------------------
-- HELPERS
---------------------------------------------------------------------------

local function sourceLabel(src, fallback)
  if src ~= 0 then
    local info = getSourceInfo(src)
    if info and info.name then
      return info.name
    end
  end
  return fallback
end

---------------------------------------------------------------------------
-- ICON DRAW HELPERS
---------------------------------------------------------------------------

local function drawBatteryIcon(x, y, w, h, percent, color)
  lcd.drawRectangle(x, y, w, h, WHITE)
  lcd.drawFilledRectangle(x + w, y + h / 3, 4, h / 3, WHITE)
  lcd.drawFilledRectangle(x + 1, y + 1, (w - 2) * percent, h - 2, color)
end

local function drawSignalIcon(x, y, size, level, color)
  color = color or WHITE
  for i = 1, 5 do
    if i <= level then
      lcd.drawFilledRectangle(
        x + (i - 1) * (size + 2),
        y + (5 - i) * size,
        size,
        i * size,
        color
      )
    end
  end
end

local function drawQualityIconFilled(x, y, r, color)
  lcd.drawFilledCircle(x, y, r, color or WHITE)
end

local function drawTempIcon(x, y, color)
  local bodyW, bodyH = 10, 30
  lcd.drawRectangle(x - bodyW / 2, y, bodyW, bodyH, WHITE)
  lcd.drawFilledRectangle(
    x - bodyW / 2 + 1,
    y + bodyH / 2,
    bodyW - 2,
    bodyH / 2 - 2,
    color
  )
  lcd.drawFilledRectangle(x - 12, y + bodyH - 4, 24, 10, color)
end

-- HELICOPTER ICON
local function drawHeliIcon(x, y, color)
  lcd.drawFilledRectangle(x + 6,  y + 12, 28, 12, color) --body
  lcd.drawFilledRectangle(x + 34, y + 14, 28, 8,  color) --boom
  lcd.drawFilledRectangle(x + 58, y + 8,  6,  18, color) --fin
  lcd.drawFilledRectangle(x + 6,  y + 26, 28, 4,  color) --skids
  lcd.drawFilledRectangle(x + 18, y + 6,  4,  6,  color) --mast
  lcd.drawFilledRectangle(x - 8, y + 4,  58, 4,  color) --main blade
end

-- PLANE ICON (based on provided silhouette)
  local function drawPlaneIcon(x, y, color)
    local xOff = 0 -- Optional offsets for fine tuning
    local yOff = -3

  lcd.drawFilledCircle(x + 5 + xOff, y + 22 + yOff, 3, color) -- fuselarge front
  lcd.drawFilledRectangle(x + 6 + xOff, y + 18 + yOff, 52, 8, color) -- Main fuselage   
  lcd.drawFilledRectangle(x + 18 + xOff, y + 5 + yOff, 9, 33, color) -- Main wing
  lcd.drawFilledRectangle(x + 45 + xOff, y + 3 + yOff, 20, 4, color) -- Tailplane  
  lcd.drawFilledRectangle(x + 52 + xOff, y + 4 + yOff, 6, 20, color) -- Vertical tail fin
end


-- DRONE ICON
local function drawDroneIcon(x, y, color)
  local yOff = -5   -- NEGATIVE = move UP, POSITIVE = move DOWN

  lcd.drawFilledRectangle(x + 22, y + 16 + yOff, 16, 8, color)  -- body
  lcd.drawFilledRectangle(x + 6,  y + 10 + yOff, 12, 4, color)  -- arm
  lcd.drawFilledRectangle(x + 42, y + 10 + yOff, 12, 4, color)
  lcd.drawFilledRectangle(x + 6,  y + 26 + yOff, 12, 4, color)
  lcd.drawFilledRectangle(x + 42, y + 26 + yOff, 12, 4, color)
end


--Detect and lock cell count for VBAT
local detectedCells = nil

---------------------------------------------------------------------------
-- REFRESH
---------------------------------------------------------------------------

local function refresh(widget)
  local z = widget.zone
  local opt = widget.options

  -- Background (hardcoded to black)
  --lcd.drawFilledRectangle(z.x, z.y, z.w, z.h,COLOR_BLACK)

  -- ARM / MOTOR STATE
  local armOn   = opt.Arm   ~= 0 and getValue(opt.Arm)   > 0
  local motorOn = opt.Motor ~= 0 and getValue(opt.Motor) > 0

  -- HELI ICON LOGIC
  local heliColor = WHITE
  local drawHeli  = true

local rssVal = (opt["Rx Signal"] ~= 0 and getValue(opt["Rx Signal"])) or 0

  if armOn  and rssVal ~= 0 then
    heliColor = RED
  end

 -- Motor ON → flashing (about 1 Hz)
 if motorOn and armOn and rssVal ~= 0 then
   if getTime() % 100 < 50 then
     drawHeli = true
   else
     drawHeli = false
   end
 end

 if motorOn and rssVal ~= 0 then
    heliColor = RED
 end
 

  lcd.drawText(
    z.x + z.w - 55,
    z.y + 6,
    model.getInfo().name or "MODEL",
    RIGHT + DBLSIZE + ((armOn and rssVal ~= 0) and RED or WHITE)
  )

  -- DATE & TIME
  local dt = getDateTime()
  local months = { "Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec" }
  lcd.drawText(z.x + z.w - 10, z.y + 8,
    string.format("%d %s", dt.day, months[dt.mon]),
    RIGHT + SMLSIZE + WHITE)
  lcd.drawText(z.x + z.w - 10, z.y + 22,
    string.format("%02d:%02d", dt.hour, dt.min),
    RIGHT + SMLSIZE + WHITE)

  -- TX BATTERY (UNCHANGED)
  local battX, battY, battW, battH = z.x + 65, z.y + 12, 96, 32
  local txV = getValue("tx-voltage") or 0
  local percent = math.max(0, math.min(1, (txV - 6.8) / (8.4 - 6.8)))

  local battColor = GREEN
  if txV < 7.1 then battColor = RED
  elseif txV <= 7.5 then battColor = YELLOW end

  lcd.drawRectangle(battX, battY, battW, battH, WHITE)
  lcd.drawFilledRectangle(battX + battW, battY + battH / 4, 6, battH / 2, WHITE)
  lcd.drawFilledRectangle(battX + 1, battY + 1,
    (battW - 2) * percent, battH - 2, battColor)
  lcd.drawText(battX + battW / 2, battY + battH / 2 - 10,
    string.format("%.1fV", txV), CENTER + WHITE + BOLD)

  -- GV DISPLAY
  if opt.GV ~= 0 then
    local gvVal = getValue(opt.GV) or 0
    lcd.drawText(
      battX + battW + 12,
      battY + battH / 2 - 9,
      string.format("%d", gvVal),
      LEFT + SMLSIZE + WHITE
    )
  end

  -------------------------------------------------------------------------
  -- SELECT ICON BASED ON GV9 FM1
  -------------------------------------------------------------------------

local gvVal = model.getGlobalVariable(8, 1) or 0


if drawHeli then
  local ix, iy = battX + battW + 50, battY

  if gvVal == 1 then
    drawPlaneIcon(ix, iy, heliColor)
  elseif gvVal == 2 then
    drawDroneIcon(ix, iy, heliColor)
  else
    drawHeliIcon(ix, iy, heliColor)
  end
end


  local sepY = battY + battH + 6
  lcd.drawFilledRectangle(battX, sepY, (z.x + z.w - 10) - battX, 2, GREY)

  -------------------------------------------------------------------------
  -- TILE LAYOUT
  -------------------------------------------------------------------------
  local tileTopY = sepY + 10
  local margin, gap = 10, 8
  local tileW = math.floor((z.w - (margin * 2) - (gap * 3)) / 4)
  local tileH = math.floor(tileW * 0.8)
  local bottomTileH = math.floor(tileH * 0.65)
  local tileBottomY = tileTopY + tileH + 6
  local tileThirdY  = tileBottomY + bottomTileH + 6

  for i = 0, 3 do
    lcd.drawRectangle(z.x + margin + i * (tileW + gap),
      tileTopY, tileW, tileH, GREY)
  end

  for i = 0, 1 do
    lcd.drawRectangle(z.x + margin + i * (tileW + gap),
      tileBottomY, tileW, bottomTileH, GREY)
  end

  local timerX = z.x + margin + (tileW + gap) * 2
  local timerW = tileW * 2 + gap
  lcd.drawRectangle(timerX, tileBottomY, timerW, bottomTileH, GREY)

  
  -------------------------------------------------------------------------
-- RX BATTERY (VBAT) TILE
-------------------------------------------------------------------------

-- Read telemetry
local vbat = (opt["Rx Batt"] ~= 0 and getValue(opt["Rx Batt"])) or 0
local teleCells = (opt["Rx Cells"] ~= 0 and getValue(opt["Rx Cells"])) or 0


-- Cell count handling (Cel# telemetry preferred)
if teleCells and teleCells >= 3 and teleCells <= 12 then
  detectedCells = teleCells
end

local cells = detectedCells or 1
local vPerCell = (cells > 0 and vbat > 0) and (vbat / cells) or 0

-- Voltage → Percentage (per-cell based)
local vMin = 3.3
local vMax = 4.2

local vPercent = (vPerCell - vMin) / (vMax - vMin)
vPercent = math.max(0, math.min(1, vPercent))

-- Color thresholds (unchanged)
local vColor = GREEN
local flash = false

if vPercent <= 0.25 then
  vColor = RED
  flash = true
elseif vPercent <= 0.50 then
  vColor = YELLOW
end

-- Flash when critical
if flash and (getTime() % 20 < 10) then
  vColor = BLACK
end

-- Draw battery icon
drawBatteryIcon(
  z.x + margin + 8,
  tileTopY + 10,
  tileW - 16,
  tileH / 3,
  vPercent,
  vColor
)

-- Draw total battery voltage
lcd.drawText(
  z.x + margin + tileW / 2,
  tileTopY + 14,
  string.format("%.2fV", vbat),
  CENTER + WHITE + BOLD
)

-- Draw per-cell voltage + cell count (from telemetry)
if rssVal ~= 0 and detectedCells and vPerCell > 0 then
  lcd.drawText(
    z.x + margin + tileW / 2,
    tileTopY + 10 + tileH / 3 + 4,
    string.format("%.2fV / %dS", vPerCell, detectedCells),
    CENTER + SMLSIZE + WHITE
  )
end

-- Draw telemetry source label
lcd.drawText(
  z.x + margin + tileW / 2,
  tileTopY + tileH - 32,
  sourceLabel(opt["Rx Batt"], "VBAT"),
  CENTER + MIDSIZE + GREY
)

  -------------------------------------------------------------------------
  -- RX SIGNAL (1RSS) TILE
  -------------------------------------------------------------------------

  local rssVal = (opt["Rx Signal"] ~= 0 and getValue(opt["Rx Signal"])) or 0 

  local rssColor = WHITE
  if rssVal <= -85 then
    rssColor = RED
  elseif rssVal <= -70 then
    rssColor = YELLOW
  elseif rssVal < 0 then
    rssColor = GREEN
  end

  drawSignalIcon(
    z.x + margin + tileW + gap + 8,
    tileTopY + 10,
    6,
    5, rssColor
  )

  lcd.drawText(
    z.x + margin + tileW + gap + tileW - 6,
    tileTopY + 6,
    string.format("%d", rssVal),
    RIGHT + MIDSIZE + WHITE)

  lcd.drawText(
    z.x + margin + tileW + gap + tileW - 6,
    tileTopY + 28,
    "dB",
    RIGHT + MIDSIZE + WHITE) 

  lcd.drawText(z.x + margin + tileW + gap + tileW / 2,
    tileTopY + tileH - 32,
    sourceLabel(opt["Rx Signal"], "1RSS"),
    CENTER + MIDSIZE + GREY)

  -------------------------------------------------------------------------
  -- RX QUALITY (RQTY) TILE
  -------------------------------------------------------------------------

  local rqtyVal = (opt["Rx Qty"] ~= 0 and getValue(opt["Rx Qty"])) or 0

  local rqtyColor = WHITE
  if rqtyVal < 1 then
    rqtyColor = WHITE
  elseif rqtyVal <= 69 then
    rqtyColor = RED
  elseif rqtyVal <= 89 then
    rqtyColor = YELLOW
  elseif rqtyVal <= 100 then
    rqtyColor = GREEN
  end

  drawQualityIconFilled(
    z.x + margin + (tileW + gap) * 2 + 16,
    tileTopY + 16,
    10, rqtyColor
  )

  lcd.drawText(
    z.x + margin + (tileW + gap) * 2 + tileW - 6,
    tileTopY + 6,
    string.format("%d%%", rqtyVal),
    RIGHT + MIDSIZE + WHITE)

  lcd.drawText(
    z.x + margin + (tileW + gap) * 2 + tileW / 2,
    tileTopY + tileH - 32,
    sourceLabel(opt["Rx Qty"], "RQTY"),
    CENTER + MIDSIZE + GREY
  )

  -------------------------------------------------------------------------
  -- ESC TEMP TILE
  -------------------------------------------------------------------------

  local tescVal = (opt["Esc Tmp"] ~= 0 and getValue(opt["Esc Tmp"])) or 0

  local escColor = WHITE
  if tescVal >= 70 then
    escColor = RED
  elseif tescVal >= 50 then
    escColor = YELLOW
  elseif tescVal > 0 then
    escColor = GREEN
  end

  drawTempIcon(
    z.x + margin + (tileW + gap) * 3 + tileW / 2 - 35,
    tileTopY + 6,
    escColor
  )


  lcd.drawText(
    z.x + margin + (tileW + gap) * 3 + tileW / 2 - 8,
    tileTopY + 6,
    string.format("%d°C", tescVal),
    LEFT + MIDSIZE + WHITE)

  lcd.drawText(z.x + margin + (tileW + gap) * 3 + tileW / 2,
    tileTopY + tileH - 32,
    sourceLabel(opt["Esc Tmp"], "TESC"),
    CENTER + MIDSIZE + GREY)

  -------------------------------------------------------------------------
  -- BOTTOM ROW (RPM / CURR)
  -------------------------------------------------------------------------

  local rpmVal  = (opt.Rpm  ~= 0 and getValue(opt.Rpm))  or 0
  local currVal = (opt.Curr ~= 0 and getValue(opt.Curr)) or 0
  local rssVal = (opt["Rx Signal"] ~= 0 and getValue(opt["Rx Signal"])) or 0

  local rpmColor = WHITE
  if rssVal ~= 0 then
    rpmColor = GREEN
  end

  lcd.drawText(z.x + margin + tileW / 2,
    tileBottomY - 2,
    string.format("%d", rpmVal),
    CENTER + MIDSIZE + rpmColor + BOLD)

  lcd.drawText(z.x + margin + tileW / 2,
    tileBottomY + bottomTileH - 28,
    sourceLabel(opt.Rpm, "RPM"),
    CENTER + MIDSIZE + GREY)

  lcd.drawText(z.x + margin + tileW + gap + tileW / 2,
    tileBottomY + 4,
    string.format("%.2fA", currVal),
    CENTER + MIDSIZE + WHITE)

  lcd.drawText(z.x + margin + tileW + gap + tileW / 2,
    tileBottomY + bottomTileH - 28,
    sourceLabel(opt.Curr, "CURR"),
    CENTER + MIDSIZE + GREY)

  -------------------------------------------------------------------------
  -- TIMER TILE
  -------------------------------------------------------------------------

local timer = model.getTimer(0)
local timeLeft = timer.value or 0
local maxTime  = timer.start or 1
local percent  = math.max(0, math.min(1, timeLeft / maxTime))

-- Always draw outline
lcd.drawRectangle(timerX + 10, tileBottomY + 8, timerW - 20, 10, WHITE)

-- Only draw bar if RSS is present
if rssVal ~= 0 then
  local barColor

  if percent <= 0.15 then
    barColor = RED
  elseif percent <= 0.5 then
    barColor = YELLOW
  else
    barColor = GREEN
  end

  lcd.drawFilledRectangle(timerX + 11, tileBottomY + 9, (timerW - 22) * percent, 8, barColor)
end

lcd.drawText(
  timerX + timerW / 2,
  tileBottomY + bottomTileH - 36,
  string.format("%02d:%02d",
    math.floor(timeLeft / 60),
    timeLeft % 60
  ),
  CENTER + DBLSIZE + WHITE
)


  -------------------------------------------------------------------------
  -- STATUS TILES
  -------------------------------------------------------------------------

  local statusTileH = math.floor(bottomTileH * 0.90)
  local statusTextY = tileThirdY + statusTileH / 2 - 20

  local motorOn = opt.Motor ~= 0 and getValue(opt.Motor) > 0
  local fm      = getFlightMode() or 0

  local texts = {
    motorOn and "Motor On" or "Motor Off",
    armOn and "ARMED" or "DISARMED",
    "FM" .. fm
  }

  local widths = {
    math.floor((timerX + timerW - (z.x + margin) - gap * 2) / 3),
    math.floor(((timerX + timerW - (z.x + margin) - gap * 2) / 3) * 1.4),
  }
  widths[3] = (timerX + timerW - (z.x + margin)) - widths[1] - widths[2] - gap * 2

  local x = z.x + margin
  for i = 1, 3 do
  
  local rssVal = (opt["Rx Signal"] ~= 0 and getValue(opt["Rx Signal"])) or 0
  
    if (i == 1 and motorOn and rssVal ~= 0) or (i == 2 and armOn and rssVal ~= 0) then
      lcd.drawFilledRectangle(x, tileThirdY, widths[i], statusTileH, RED)

    elseif (i == 1 and rssVal ~= 0) or (i == 2 and rssVal ~= 0) then
      lcd.drawFilledRectangle(x, tileThirdY, widths[i], statusTileH, GREEN)
    
    elseif i == 3 and rssVal ~= 0 and armOn then
    lcd.drawFilledRectangle(x, tileThirdY, widths[i], statusTileH, RED)
    
    elseif i == 3 and rssVal ~= 0 then
    lcd.drawFilledRectangle(x, tileThirdY, widths[i], statusTileH, GREEN)
    end

    lcd.drawRectangle(x, tileThirdY, widths[i], statusTileH, GREY)
    lcd.drawText(x + widths[i] / 2, statusTextY,
      texts[i], CENTER + DBLSIZE + WHITE)
    x = x + widths[i] + gap
  end
end

---------------------------------------------------------------------------

return {
  name = name,
  create = create,
  refresh = refresh,
  update = update,
  options = options
}
